<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				<p>DEATH IS NOT THE ESCAPE</p>
			</div>

		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>